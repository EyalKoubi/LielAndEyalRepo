import "../../CSS/App.css";

// component for the
// the button of login
const LogInButton = () => {
  return (
    <button type="submit" className="login-button">
      Log in
    </button>
  );
};

export default LogInButton;
