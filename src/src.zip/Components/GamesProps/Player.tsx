import Navbar from "./Navbar";
import "../../CSS/GamesProps/Player.css";

// player component for player screen
const Player = () => {
  return (
    <div className="all">
      <div className="App">
        <div className="title">
          <Navbar></Navbar>
        </div>
      </div>
    </div>
  );
};

export default Player;
